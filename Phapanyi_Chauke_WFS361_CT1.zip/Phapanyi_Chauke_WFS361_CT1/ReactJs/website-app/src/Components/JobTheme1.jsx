import React from 'react'
import Img1 from './Assets/pic-1.PNG'

function JobTheme1() {
  return (
    <div className= "Theme">
         <img src={Img1} alt="image1" />
        <section>
        
         
      <h3 className="GroupMain">Graphic design</h3>
      <p className= "Description">Praesent dignissim nibh quis ante dignissim, in dui feugiat.
      Duis elit dul, vestibulum nec ipsum id, finibus sollicitudin elit.
      </p>
      <footer>+ Read More</footer>
      </section>
      
      
    </div>
  )
}

export default JobTheme1
