import React from 'react'
import Img2 from './Assets/pic-2.PNG'

function JobTheme2() {
  return (
    <div  className= "Theme">
        <img src={Img2} alt="image2" />
        <section >
         
         
        <h3 className="GroupMain">Web development</h3>
        <p className= "Description">Duis euismod diam sit amet sem bibendum. Praesent in
        luctus dui, eget mollis libero vivamus justo augue consectetur urpis magna.
        </p>
        <footer>+ Read More</footer>
        </section>
      
        
    </div>
  )
}

export default JobTheme2
