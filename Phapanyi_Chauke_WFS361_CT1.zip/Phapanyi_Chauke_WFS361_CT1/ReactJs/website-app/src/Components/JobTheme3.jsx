import React from 'react'
import Img3 from './Assets/pic-3.PNG';

function JobTheme3() {
  return (
    <div  className= "Theme">
         <img src={Img3} alt="image3" />
        <section>
        
         
        <h3 className="GroupMain">Marketing</h3>
        <p className= "Description">Mauris lectus urna, rutrum a felis a, consectetur placerat quam.
        Quisque placerat turpis magna, et aliquam eros digissim eu.
        </p>
        <footer>+ Read More</footer>
        </section>
       
       
    </div>
  )
}

export default JobTheme3
