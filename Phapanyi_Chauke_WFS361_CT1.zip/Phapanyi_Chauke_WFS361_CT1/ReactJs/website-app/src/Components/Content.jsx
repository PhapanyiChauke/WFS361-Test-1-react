import React from 'react'
import JobTheme1 from '../Components/JobTheme1.jsx';
import JobTheme2 from '../Components/JobTheme2.jsx';
import JobTheme3 from '../Components/JobTheme3.jsx';


function Content() {
  return (
    <div id="GroupMain">
      <JobTheme1 />
      <JobTheme2 />
      <JobTheme3 />

    </div>
  )
}

export default Content
