import React from 'react'

export default function Header() {
  return (
    <div>
      <header>
        <h3>What i do</h3>
        <p>Praesent dignissim nibh quis ante dignissim, in posuere dui feugiat. 
            duis elit dui, vestibulum nec
            ipsum id, finibus sollicitudin elit. cras et purus sagittis, volutpat est id
        </p>
      </header>
    </div>
  )
}
